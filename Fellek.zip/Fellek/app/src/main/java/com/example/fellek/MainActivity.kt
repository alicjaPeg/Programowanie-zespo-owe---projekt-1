package com.example.fellek

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        play_button.setOnClickListener() {
            val intent = Intent(this, GameActivity::class.java)
            startActivity(intent)
        }
        score_table_button.setOnClickListener() {
            val intent = Intent(this, ScoreTable::class.java)
            startActivity(intent)
        }
        options_button.setOnClickListener() {
            val intent = Intent(this, OptionsActivity::class.java)
            startActivity(intent)
        }
        exit_button.setOnClickListener() {
            val intent = Intent(this, ExitActivity::class.java)
            startActivity(intent)
        }

    }

}
